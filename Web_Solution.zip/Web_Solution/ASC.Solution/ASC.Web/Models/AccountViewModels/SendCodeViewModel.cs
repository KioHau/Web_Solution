﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASC.Web.Models
{
    class SendCodeViewModel
    {
    }
}
